import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {

   items: any[];
   images =  [{}];
   responsiveOptions: any[];

  constructor() { 
    this.items = [
      { label: 'Home', icon: 'pi pi-fw pi-home', routerLink: '/' },
      { label: 'Sair', icon: 'pi pi-fw pi-sign-out', routerLink: '/'  }
    ];

    this.images = [
      { previewImageSrc: 'assets/user.png', thumbnailImageSrc: 'assets/user.png' },
      { previewImageSrc: 'assets/roxxa.jpg', thumbnailImageSrc: 'assets/user.png' },
    ];

    this.responsiveOptions = [
      {
          breakpoint: '1024px',
          numVisible: 5
      },
      {
          breakpoint: '960px',
          numVisible: 4
      },
      {
          breakpoint: '768px',
          numVisible: 3
      },
      {
          breakpoint: '560px',
          numVisible: 1
      }
  ];
  }

  ngOnInit(): void {
    //this.photoService.getImages().then(images => this.images = images);
  }

  atualizarPagina() {
    // Lógica para atualizar a página
  }

  sair() {
    // Lógica para sair
  }

}
